<template>
  <div class="container">
      我是otherNode
  </div>
</template>

<script>
import '@antv/x6-vue-shape'
// import { Node } from '@antv/x6'

export default {
  name: 'ChangeSize',
  inject: ['getNode', 'getGraph']

  // props: {
  //   pnode: {
  //     type: Node,
  //     default: null,
  //     required: true
  //   }
  // },
  // mounted () {
  //   this.getGraph().addEdge(this.getNode(), this.pnode)
  // }
}
</script>
<style scoped>
.container {
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
