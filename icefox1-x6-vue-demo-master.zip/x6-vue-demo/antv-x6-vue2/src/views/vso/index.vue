<template>
  <a-drawer
    placement="right"
    :closable="true"
    :visible="visible"
    width="100%"
    @close="onClose"
  >
    <div id="vso" />

  </a-drawer>
</template>

<script>
import { Graph } from '@antv/x6'
import '@antv/x6-vue-shape'
import ChangeSize from './components/ChangeSize'
import AddNode from '@/views/vso/components/AddNode'
export default {
  name: 'index',
  data () {
    return {
      visible: false,
      graph: ''
    }
  },
  methods: {
    showDrawer () {
      setTimeout(() => {
        this.initGraph()
      }, 100)
      this.visible = true
    },
    initGraph () {
      this.graph = new Graph({
        container: document.getElementById('vso'),
        width: 600,
        height: 400,
        grid: true
      })

      // 官方的写法
      this.graph.addNode({
        shape: 'vue-shape',
        x: 300,
        y: 100,
        width: 150,
        height: 100,
        attrs: {
          body: {
            stroke: '#ebebeb'
          }
        },
        component: {
          template: '<change-size></change-size>',
          data () {
            return {
            }
          },
          methods: {

          },
          components: {
            ChangeSize
          }
        }
      })

      // node中新增node
      this.graph.addNode({
        shape: 'vue-shape',
        x: 200,
        y: 300,
        width: 150,
        height: 100,
        attrs: {
          body: {
            stroke: '#ebebeb'
          }
        },
        component: {
          // 初始化的第一个node
          // 相当于第一个div
          template: '<add-node></add-node>',
          data () {
            return {
            }
          },
          methods: {
          },
          components: {
            AddNode
          }
        }
      })
    },
    onClose () {
      this.graph.dispose()
      this.visible = false
    }
  }

}
</script>

<style scoped>

</style>
