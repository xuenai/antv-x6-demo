<template>
  <a-drawer
    placement="right"
    :closable="true"
    :visible="visible"
    width="100%"
    @close="onClose"
  >

  </a-drawer>
</template>

<script>
import styles from './index.less'

export default {
  name: 'index',
  components: {
  },
  data () {
    return {
      visible: false,
      graph: '',
      styles: styles
    }
  },
  methods: {

    showDrawer () {
      // setTimeout(() => {
      //   this.initGraph()
      // }, 100)
      this.visible = true
    },

    onClose () {
      // this.graph.dispose()
      this.visible = false
    }
  }
}
</script>

<style scoped>

</style>
