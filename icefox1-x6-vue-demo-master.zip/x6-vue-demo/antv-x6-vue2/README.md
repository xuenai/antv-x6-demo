# antv-x6-vue2

## demo效果图

![1](./src/assets/demo/1.png)

![2](./src/assets/demo/2.png)

![3](./src/assets/demo/3.png)

![4](./src/assets/demo/4.png)


## Project setup
```
yarn install
```

### Compiles and hot-reloads for development
```
yarn serve
```

### Compiles and minifies for production
```
yarn build
```

### Lints and fixes files
```
yarn lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
