
// vue.config.js

module.exports = {
  // 在项目配置的时候，默认 npm 包导出的是运行时构建，即 runtime 版本，不支持编译 template 模板。
  runtimeCompiler: true
}
