<template>
  <div id="nav">
    <router-link to="/">Home</router-link> |
    <router-link to="/about">About</router-link>|
    <router-link to="/undo">undo</router-link>|
    <router-link to="/transitions">transitions</router-link>|
    <router-link to="/switch">switch</router-link>|
    <router-link to="/transform">transform</router-link>|
    <router-link to="/tool/clean">toolClean</router-link>|

    <router-link to="/tool/contextmenu">toolContextMenu</router-link>|
    <router-link to="/tool/tooltip">tooltip</router-link>|


    <router-link to="/token">token</router-link>|

    <router-link to="/stencil">stencil</router-link>|

    <router-link to="/snapline">snapline</router-link>|
    <router-link to="/shap">shap</router-link>|
    <router-link to="/xml-markup">xml-markup</router-link>|
    <router-link to="/standard">standard</router-link>|
    <router-link to="/helloworld">helloworld</router-link>|
    <router-link to="/custom-node">custom-node</router-link>|
    <router-link to="/coord">coord</router-link>|
    <router-link to="/basic">basic</router-link>|
    <router-link to="/shap/flowchart">shap-flowchart</router-link>|
    <router-link to="/selection">selection</router-link>|
    <router-link to="/scroller">scroller</router-link>|
    <router-link to="/router">router</router-link>|
    <router-link to="/router/orth">router-orth</router-link>|
    <router-link to="/react">react</router-link>|

    <router-link to="/react/label">react-label</router-link>|
    <router-link to="/react/port">react-port</router-link>|




  </div>
  <router-view/>
</template>

<style lang="less">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;

  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
</style>
