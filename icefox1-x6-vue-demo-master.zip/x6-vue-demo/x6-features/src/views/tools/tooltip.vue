<template>
<div>
  我有问题
</div>
</template>

<script>
export default {
  name: "tooltip"
}
</script>

<style scoped>

</style>
